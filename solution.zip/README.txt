Yulun Zeng

When I was doing milestone 1, I did not implement high level code gen for data structures like nested array, array as struct field, and array of struct. As a result, I spent a lot of time adding those functionalities in highlevel code gen. 

For milestone 2, it was pretty straight foward. I just had to create some sort of mapping from high level to low level. There were a lot of reusable code, so I split the mapping into a few parts to avoid redundancies. The biggest challenge for this assignment was really code organization rather than problem solving.

I spent a lot of time on other coursework over the thanksgiving break, and I am barely catching up. I was only able to get 26 cases working, I am going to work on the nested arrays some time later, since they are needed for milestone 5.